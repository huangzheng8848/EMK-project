#include <pwm.h>

// ================= Hardware-Pins und Objekte =================
PwmOut AusgabeStromLA(5);
PwmOut AusgabeStromMSM(6);

const int analogStromLA = A4;  // LA Ist-Strom einlesen
const int analogStromSP = A5;  // MSM Ist-Strom einlesen 
const int inLaser = A1;        // Laser-Wegsensor

int inLA1 = 12; int inLA2 = 13;
int inMSM1 = 9; int inMSM2 = 10;

// ================= Variablen und PI-Parameter =================
float nullReferenzLaser = 0.0;
float auslenkung = 0.0;
float dehnungMSM = 0.0;
String befehl = "";

// MSM PI-Parameter 
float KpMSM = 30.0, KiMSM = 20.0;
float integralMSM = 0;

float KpLA = 0.1, KiLA = 20;
float integralLA = 0;

float istStromLA = 0;
float pwm_out_LA = 0;
float pwm_out_MSM = 0;

// ================= Hilfsfunktion: Median-Average-Filter =================
// Liest 5 Werte ein, entfernt das Maximum und das Minimum und mittelt die restlichen 3.
float readFilteredAnalog(int pin) {
  int values[5];
  
  // 5 Werte schnell einlesen
  for (int i = 0; i < 5; i++) {
    values[i] = analogRead(pin);
    delay(2); // Kurze Pause fuer den ADC
  }

  // Bubble Sort um die Werte zu sortieren (klein zu gross)
  for (int i = 0; i < 4; i++) {
    for (int j = 0; j < 4 - i; j++) {
      if (values[j] > values[j + 1]) {
        int temp = values[j];
        values[j] = values[j + 1];
        values[j + 1] = temp;
      }
    }
  }

  // Den kleinsten (Index 0) und groessten (Index 4) Wert ignorieren.
  // Summe aus Index 1, 2 und 3 bilden und durch 3 teilen.
  float sum = values[1] + values[2] + values[3];
  return sum / 3.0;
}

void setup() {
  Serial.begin(9600); 

  // Initialisierung der PWM-Ausgänge mit 20kHz
  AusgabeStromLA.begin(20000.0f, 0.0f);
  AusgabeStromMSM.begin(20000.0f, 0.0f);

  pinMode(analogStromLA, INPUT);
  pinMode(analogStromSP, INPUT); 
  pinMode(inLaser, INPUT);

  // LA Richtungskonfiguration
  pinMode(inLA1, OUTPUT); pinMode(inLA2, OUTPUT);
  digitalWrite(inLA1, LOW); digitalWrite(inLA2, HIGH);

  // MSM Richtungskonfiguration
  pinMode(inMSM1, OUTPUT); pinMode(inMSM2, OUTPUT);
  digitalWrite(inMSM1, HIGH); digitalWrite(inMSM2, LOW);
  
  delay(1000);
  Serial.println("BEREIT_FUER_PYTHON"); 
}

void loop() {
  if (Serial.available()) {
    befehl = Serial.readStringUntil('\n');
    befehl.trim();
    
    // ====================================================
    // BEFEHL 1: INIT - Initialisierung & Entmagnetisierung bei -1.0A
    // ====================================================
    if (befehl == "INIT") {
      // A. MSM-Kristall "erweichen" (-1.0A)
      digitalWrite(inMSM1, HIGH);
      digitalWrite(inMSM2, LOW);
      float sollPWMMSM = 1.0 * 48.03281581 + 51.78413903; 
      AusgabeStromMSM.pulse_perc(sollPWMMSM); 

      // B. LA legt initiale Rücksetzkraft von 8.6N an
      float initKraftLA = 8.6;
      float initStromLA = initKraftLA / 6.0;
      float initPWMLA = initStromLA * 36.6571359 + 46.71291013;
      AusgabeStromLA.pulse_perc(initPWMLA);

      delay(1500); 
      
      // C. Laser-Nullpunkt im vollständig komprimierten Zustand einlesen (mit Filter!)
      float rawZero = readFilteredAnalog(inLaser);
      nullReferenzLaser = (rawZero * 5.0 / 1023.0) * 7.7 / 3.98;
      delay(1000); 

      // D. Standardkraft für den Testbetrieb auf 4.0N setzen
      float sollKraftLA = 4.0; 
      float zielStromLA = constrain(sollKraftLA / 6.0, 0.0, 1.5);
      float basePWMLA = zielStromLA * 36.6571359 + 46.71291013;

      // Rückmeldung an Python: Initialisierung abgeschlossen
      Serial.println("DONE"); 
    }
    
    // ====================================================
    // BEFEHL 2: C:xxx - Sollstrom empfangen und Closed-Loop ausführen
    // ====================================================
    else if (befehl.startsWith("C:")) {
      
      // Extrahiere Stromwert (z.B. "0.45" aus "C:0.45")
      String currentStr = befehl.substring(2);
      float sollStromMSM = currentStr.toFloat();
      
      float sollKraftLA = 4.0; // Konstante Druckkraft von 4.0N halten
      float zielStromLA = constrain(sollKraftLA / 6.0, 0.0, 1.5);
      float basePWMLA = zielStromLA * 36.6571359 + 46.71291013;
      
      float zielStromMSM_abs = abs(sollStromMSM);
      
      // MSM Polaritätsumschaltung (H-Brücke)
      if (sollStromMSM < 0) {
        digitalWrite(inMSM1, HIGH); digitalWrite(inMSM2, LOW);
      } else {
        digitalWrite(inMSM1, LOW); digitalWrite(inMSM2, HIGH);
      }

      integralMSM = 0; // PI-Integrator zurücksetzen
      integralLA = 0;

      // 2,0 Sekunden PI-Regelungsphase zur Stabilisierung (Laut Code 3.5s)
      long sampleTime_ms = 10;       
      unsigned long duration = 3500; 
      unsigned long startTime = millis();
      unsigned long lastSampleTime = millis();
      
      float gemessenerStromMSM = 0.0; 
      
      while (millis() - startTime < duration) {
        unsigned long now = millis();
        if(now - lastSampleTime >= sampleTime_ms) {
          lastSampleTime = now;
          
          // --- A. MSM PI-Regelkreis (Strom mit Filter einlesen!) ---
          float filteredRawStrom = readFilteredAnalog(analogStromSP);
          float istStromSP = (filteredRawStrom * 5.0) / (1023.0 * 1.5);
          gemessenerStromMSM = istStromSP;

          float errorMSM = zielStromMSM_abs - istStromSP;
          integralMSM += (KiMSM * errorMSM);
          integralMSM = constrain(integralMSM, -100, 100); 
          pwm_out_MSM = (KpMSM * errorMSM) + integralMSM;
          pwm_out_MSM = constrain(pwm_out_MSM, 0.0, 100.0);
          AusgabeStromMSM.pulse_perc(pwm_out_MSM);

          // --- B. LA PI-Regelkreis (konstante 4.0N halten) ---
          istStromLA = (analogRead(analogStromLA) * 5.0) / (1023.0 * 1.5);
          float errorLA = zielStromLA - istStromLA;
          integralLA += ( KiLA * errorLA );
          integralLA = constrain(integralLA, -100, 100); 
          pwm_out_LA = basePWMLA + (KpLA * errorLA) + integralLA;
          pwm_out_LA = constrain(pwm_out_LA, 0.0, 100.0);
          AusgabeStromLA.pulse_perc(pwm_out_LA);
        }
      } 

      // Nach Stabilisierung: Aktuelle Dehnung berechnen (Laser mit Filter einlesen!)
      float rawVal = readFilteredAnalog(inLaser);
      auslenkung = (rawVal * 5.0 / 1023.0) * 7.7 / 3.98;
      
      // Berechnung der relativen Dehnung in Prozent
      // Formel: ((L_null - L_aktuell) / L_referenz) * 100
      dehnungMSM = ((nullReferenzLaser - auslenkung) / 15.0) * 100.0;
      
      float printStromMSM = (sollStromMSM < 0) ? -gemessenerStromMSM : gemessenerStromMSM;

      // Statusdaten für die Python-Konsole senden
      Serial.print("Data: IstStrom=");
      Serial.print(printStromMSM);
      Serial.print(" A, Dehnung=");
      Serial.print(dehnungMSM);
      Serial.println(" %");

      //Signalisiert Python das Ende der Aktion
      Serial.println("DONE"); 
    }
    // ====================================================
    // BEFEHL 3: OVER - Experiment beenden, Strom abschalten
    // ====================================================
    else if (befehl == "OVER") {
      AusgabeStromLA.pulse_perc(0.0f);
      AusgabeStromMSM.pulse_perc(0.0f);
      
      // Bestätigung der sicheren Abschaltung
      Serial.println("SHUTDOWN_DONE");
    }
  }
}