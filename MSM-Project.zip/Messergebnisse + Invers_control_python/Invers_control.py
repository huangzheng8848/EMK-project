import os
import glob
import re
import time
import serial
import numpy as np
import pandas as pd
from scipy.interpolate import CloughTocher2DInterpolator, NearestNDInterpolator, interp1d
from scipy.optimize import brentq
import plotly.graph_objects as go
import matplotlib.pyplot as plt

# ================= GLOBALE KONFIGURATION =================
# Pfad zum Ordner mit den CSV-Dateien für das Preisach-Modell
FOLDER_PATH = r"C:\Users\16771\Desktop\2025_2026冬季学期\PROJEKT\新建文件夹\Automatischer_Modus_mit_Array\MSM_Dehnung\CSV_3次（间隔0.1A）平均值"
SERIAL_PORT = 'COM3'  # COM-Port des Arduinos
BAUD_RATE = 9600  # Baudrate für die serielle Kommunikation


# =========================================================


class PreisachController:
    """
    Diese Klasse implementiert einen Regler basierend auf dem Preisach-Hysteresemodell.
    Sie kombiniert eine modellbasierte Vorsteuerung (Feedforward) mit einem
    proportionalen Feedback-Regler (P-Regler), um Hysterese-Effekte zu kompensieren.
    """

    def __init__(self, folder_path):
        print("Initialisiere Preisach-Engine mit industrieller Reglerstruktur (FF + P)...")

        # Physikalische Grenzen des Systems (Strom in Ampere)
        self.min_curr = -1.0
        self.max_curr = 1.0

        # Aufbau der Everett-Funktion (physikalisches Modell) aus CSV-Daten
        self._build_everett_map(folder_path)

        # Speicher für die Extremwerte (Wiping-Out-Eigenschaft des Preisach-Modells)
        self.history_I = [self.min_curr]
        self.history_f = [self.f_min]

        # Zustandsvariablen für den aktuellen Regelzyklus
        self.last_input_strain = 0.0
        self.last_real_strain = self.f_min
        self.last_applied_I = self.min_curr

        self.offset_up = 0.0
        self.offset_down = 0.0

        # Richtungs-Tracking (Aufwärts- oder Abwärtsast der Hysterese)
        self.is_currently_going_up = True
        self.last_direction_was_up = True

    def _build_everett_map(self, folder_path):
        """
        Liest FORC-Kurven (First-Order Reversal Curves) aus CSV-Dateien ein,
        extrahiert die Wendepunkte und berechnet die 2D-Everett-Interpolationsfläche.
        """
        file_paths = glob.glob(os.path.join(folder_path, "averaged_forc_*.csv"))

        global_f_min = float('inf')
        raw_data_list = []

        # 1. Alle FORC-Dateien einlesen und Extremwerte ermitteln
        for file in file_paths:
            match = re.search(r"averaged_forc_([-+]?\d*\.?\d+)A\.csv", os.path.basename(file))
            if not match: continue

            df = pd.read_csv(file)
            curr_arr = df['Current'].values
            strain_arr = df['Strain'].values

            min_strain = np.min(strain_arr)
            if min_strain < global_f_min:
                global_f_min = min_strain

            peak_idx = np.argmax(curr_arr)
            alpha_actual = curr_arr[peak_idx]
            f_alpha = strain_arr[peak_idx]

            raw_data_list.append({
                'alpha': alpha_actual,
                'f_alpha': f_alpha,
                'betas': curr_arr[peak_idx:],
                'f_betas': strain_arr[peak_idx:]
            })

        self.f_min = global_f_min
        raw_data_list.sort(key=lambda x: x['alpha'])

        alpha_list, beta_list, E_list = [], [], []
        alpha_peaks = [self.min_curr]
        f_peaks = [self.f_min]

        # 2. Everett-Werte berechnen: E(alpha, beta) = 0.5 * (f(alpha) - f(alpha, beta))
        for data in raw_data_list:
            alpha = data['alpha']
            f_alpha = data['f_alpha']
            alpha_peaks.append(alpha)
            f_peaks.append(f_alpha)

            for beta, f_beta in zip(data['betas'], data['f_betas']):
                alpha_list.append(alpha)
                beta_list.append(beta)
                E_list.append(0.5 * (f_alpha - f_beta))

        # Interpolationsfunktion für die Hauptkurve (Peak-Werte)
        self.f_peak_func = interp1d(alpha_peaks, f_peaks, bounds_error=False, fill_value=(f_peaks[0], f_peaks[-1]))

        self.data_min_curr = min(beta_list)
        self.data_max_curr = max(alpha_list)

        self.E_points = np.column_stack((alpha_list, beta_list))
        self.E_values = np.array(E_list)

        # 3. 2D-Interpolatoren erstellen (CloughTocher für weiche Übergänge, NearestND als Fallback)
        self.E_func_smooth = CloughTocher2DInterpolator(self.E_points, self.E_values)
        self.E_func_nearest = NearestNDInterpolator(self.E_points, self.E_values)
        print(f"Physikalisches Feld erfolgreich geladen! f_min = {self.f_min:.4f} @ {self.data_min_curr:.4f}A")

    def update_everett_map(self, alpha, beta, new_E):
        """
        Online-Lernfunktion: Aktualisiert die Everett-Fläche dynamisch,
        wenn reale Messwerte von den theoretischen Modellwerten abweichen.
        """
        alpha = np.clip(alpha, self.data_min_curr, self.data_max_curr)
        beta = np.clip(beta, self.data_min_curr, self.data_max_curr)

        # Sicherstellen, dass alpha >= beta ist (physikalische Bedingung)
        if beta > alpha:
            alpha, beta = beta, alpha

        idx = -1
        # Prüfen, ob der Punkt (alpha, beta) bereits in den Daten existiert
        for i, pt in enumerate(self.E_points):
            if abs(pt[0] - alpha) < 1e-3 and abs(pt[1] - beta) < 1e-3:
                idx = i
                break

        # Bei Existenz: Mittelwert aus altem und neuem Wert bilden. Sonst: Neuen Punkt hinzufügen.
        if idx != -1:
            self.E_values[idx] = 0.5 * self.E_values[idx] + 0.5 * new_E
        else:
            self.E_points = np.vstack((self.E_points, [alpha, beta]))
            self.E_values = np.append(self.E_values, new_E)

        # Interpolatoren mit den neuen Datenpunkten neu berechnen
        try:
            self.E_func_smooth = CloughTocher2DInterpolator(self.E_points, self.E_values)
            self.E_func_nearest = NearestNDInterpolator(self.E_points, self.E_values)
            print(
                f"      [System] Online-Learning: Everett-Map aktualisiert -> E({alpha:.3f}, {beta:.3f}) = {new_E:.4f}")
        except Exception as e:
            print(f"      [System] Warnung: Everett-Map Update fehlgeschlagen ({e})")

    def plot_everett_map(self):
        """Generiert eine interaktive 3D-Darstellung der Everett-Fläche im Browser."""
        print("Rendere 3D-Everett-Map im Browser...")
        ai = np.linspace(self.data_min_curr, self.data_max_curr, 100)
        bi = np.linspace(self.data_min_curr, self.data_max_curr, 100)
        AI, BI = np.meshgrid(ai, bi)
        ZI = self.E_func_smooth(AI, BI)

        # Bereich ausblenden, in dem beta > alpha ist (unphysikalisch)
        ZI[BI > AI] = None
        fig = go.Figure(data=[go.Surface(z=ZI, x=AI, y=BI, colorscale='Viridis')])
        fig.show()

    def get_E(self, alpha, beta):
        """Holt den interpolierten Everett-Wert für ein gegebenes Paar (alpha, beta)."""
        alpha = np.clip(alpha, self.data_min_curr, self.data_max_curr)
        beta = np.clip(beta, self.data_min_curr, self.data_max_curr)
        beta = min(alpha, beta)

        val = self.E_func_smooth(alpha, beta)
        if np.isnan(val):
            val = self.E_func_nearest(alpha, beta)
        return float(val) if not np.isnan(val) else 0.0

    def _simulate_forward(self, I_test):
        """
        Simuliert die Wiping-Out-Eigenschaft des Preisach-Modells.
        Löscht innere Hystereseschleifen, wenn diese von größeren Schleifen überschrieben werden.
        """
        temp_I = self.history_I.copy()
        temp_f = self.history_f.copy()

        if abs(I_test - temp_I[-1]) < 1e-6:
            return temp_I, temp_f

        # Fall 1: Strom steigt (Aufwärtsast)
        if I_test > temp_I[-1]:
            if len(temp_I) % 2 == 0:
                temp_I.pop()
                temp_f.pop()

            # Alle umhüllten (kleineren) Zyklen löschen
            while len(temp_I) >= 3 and I_test >= temp_I[-2]:
                temp_I.pop()
                temp_I.pop()
                temp_f.pop()
                temp_f.pop()

            temp_I.append(I_test)
            if len(temp_I) == 2:
                temp_f.append(float(self.f_peak_func(I_test)))
            else:
                temp_f.append(temp_f[-1] + 2 * self.get_E(I_test, temp_I[-2]))

        # Fall 2: Strom sinkt (Abwärtsast)
        elif I_test < temp_I[-1]:
            if len(temp_I) % 2 == 1 and len(temp_I) > 1:
                temp_I.pop()
                temp_f.pop()

            # Alle umhüllten (kleineren) Zyklen löschen
            while len(temp_I) >= 3 and I_test <= temp_I[-2]:
                temp_I.pop()
                temp_I.pop()
                temp_f.pop()
                temp_f.pop()

            temp_I.append(I_test)
            temp_f.append(temp_f[-1] - 2 * self.get_E(temp_I[-2], I_test))

        return temp_I, temp_f

    def calculate_forward_strain(self, I_test):
        """Rein mathematische Vorhersage der Dehnung für einen gegebenen Test-Strom."""
        _, temp_f = self._simulate_forward(I_test)
        return temp_f[-1]

    def commit_current(self, I_applied, actual_strain=None, target_strain=None):
        """
        Speichert den tatsächlich angelegten Strom endgültig in der Historie ab.
        Falls der physikalische Ist-Wert zu stark vom Modell abweicht, wird das Online-Learning getriggert.
        """
        self.history_I, self.history_f = self._simulate_forward(I_applied)

        if actual_strain is not None:
            self.last_real_strain = actual_strain
            self.last_applied_I = I_applied

            if target_strain is not None:
                error = abs(actual_strain - target_strain)

                # Toleranzbereich: Kein Update der Map nötig
                if error <= 0.06:
                    return
                else:
                    # Map mit dem realen Messwert korrigieren
                    if len(self.history_I) >= 2:
                        if self.last_direction_was_up:
                            alpha = I_applied
                            beta = self.history_I[-2]
                            new_E = (actual_strain - self.history_f[-2]) / 2.0
                        else:
                            alpha = self.history_I[-2]
                            beta = I_applied
                            new_E = (self.history_f[-2] - actual_strain) / 2.0

                        new_E = max(0.0, float(new_E))
                        self.update_everett_map(alpha, beta, new_E)

                    # Theorie durch die physikalische Realität ersetzen
                    old_f = self.history_f[-1]
                    self.history_I[-1] = I_applied
                    self.history_f[-1] = actual_strain
                    print(
                        f"      [System] Sandbox Update: Theorie ({old_f:.3f}%) durch Realitaet ({actual_strain:.3f}%) ueberschrieben.")
                    return

    def get_required_current(self, target_strain):
        """
        Haupt-Kontrollalgorithmus: Berechnet den benötigten Strom, um die Zieldehnung zu erreichen.
        Nutzt dafür Modell-Invertierung (brentq) und addiert einen P-Regelanteil zur Fehlerkorrektur.
        """
        I_curr = self.history_I[-1]
        current_physical_strain = self.last_real_strain
        error = target_strain - current_physical_strain

        # Ziel bereits innerhalb der Toleranz erreicht
        if abs(error) <= 0.06:
            return I_curr

        # Erkennung, ob ein neues Ziel vorgegeben wurde
        is_new_target = abs(target_strain - self.last_input_strain) >= 1e-4

        if is_new_target:
            self.is_currently_going_up = target_strain > current_physical_strain
            self.last_input_strain = target_strain
        else:
            # Overshoot-Behandlung (Ziel überschossen -> Umkehrung der Suchrichtung)
            if self.is_currently_going_up and error < -0.06:
                print("      [System] Overshoot (> 0.06%)! Wechsle in den Rueckweg-Modus (Abwaerts).")
                self.is_currently_going_up = False
            elif not self.is_currently_going_up and error > 0.06:
                print("      [System] Overshoot (> 0.06%)! Wechsle in den Hinweg-Modus (Aufwaerts).")
                self.is_currently_going_up = True

        is_going_up = self.is_currently_going_up
        self.last_direction_was_up = is_going_up

        I_curr_clamped = np.clip(I_curr, self.min_curr, self.max_curr)
        active_offset = self.offset_up if is_going_up else self.offset_down
        theoretical_target = target_strain - active_offset

        max_theoretical_strain = float(self.f_peak_func(self.max_curr))
        theoretical_target = np.clip(theoretical_target, 0.0, max_theoretical_strain)
        current_theoretical_strain = self.history_f[-1]

        I_model = I_curr_clamped

        # Modell-Invertierung mithilfe des Brent-Verfahrens zur Bestimmung des Feedforward-Stroms
        if is_going_up:
            if theoretical_target <= current_theoretical_strain:
                theoretical_target = current_theoretical_strain + 1e-4
            try:
                if I_curr_clamped >= self.max_curr:
                    I_model = self.max_curr
                else:
                    I_model = brentq(lambda I: self.calculate_forward_strain(I) - theoretical_target, I_curr_clamped,
                                     self.max_curr)
            except ValueError:
                I_model = self.max_curr
        else:
            if theoretical_target >= current_theoretical_strain:
                theoretical_target = current_theoretical_strain - 1e-4
            try:
                if I_curr_clamped <= self.min_curr:
                    I_model = self.min_curr
                else:
                    I_model = brentq(lambda I: self.calculate_forward_strain(I) - theoretical_target, self.min_curr,
                                     I_curr_clamped)
            except ValueError:
                I_model = self.min_curr

        # --- Vorsteuerung (Feedforward) mit Newton-Relaxation (Dämpfung) ---
        alpha = 0.3
        delta_i = I_model - I_curr_clamped
        I_ff = I_curr_clamped + alpha * delta_i

        # --- Rückführung (P-Regler / Feedback) ---
        K_p = 0.5
        I_fb = K_p * error

        # --- Finaler Output-Strom ---
        I_out = I_ff + I_fb
        I_out_clamped = np.clip(I_out, self.min_curr, self.max_curr)

        print(
            f"      [Regler] Zielstrom-Berechnung: Model={I_model:.4f}A | FF(a={alpha})={I_ff:.4f}A | FB(Kp={K_p})={I_fb:+.4f}A  ➔ Output={I_out_clamped:.4f}A")

        return float(I_out_clamped)


def main():
    # 1. Controller initialisieren und 3D-Map anzeigen
    controller = PreisachController(FOLDER_PATH)
    controller.plot_everett_map()

    # 2. Serielle Verbindung zum Arduino herstellen
    print(f"Verbinde mit Arduino ({SERIAL_PORT})...")
    try:
        ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=2)
        time.sleep(2)
    except Exception as e:
        print(f"Fehler bei serieller Verbindung: {e}")
        return

    # 3. Hardware initialisieren (z.B. Entmagnetisierungslauf)
    print("Initialisiere System und de-magnetisiere...")
    ser.write(b"INIT\n")

    while True:
        line = ser.readline().decode('utf-8', errors='ignore').strip()
        if line == "DONE":
            print("Initialisierung abgeschlossen!")
            print("-" * 50)
            break

    # --- Arrays für das Plotten der Ergebnisse am Ende ---
    path_currents = []  # Kompletter Suchpfad (Strom)
    path_strains = []  # Kompletter Suchpfad (Dehnung)
    final_targets = []  # Theoretische Zielvorgaben
    final_currents = []  # Ströme am Ende eines Suchzyklus
    final_strains = []  # Erreichte Ist-Dehnungen am Ende eines Suchzyklus

    # 4. Hauptschleife für die Benutzereingabe
    while True:
        try:
            val = input("\nBitte Ziel-Dehnung (in %) eingeben (z.B. 0.5, 'q' zum Beenden): ")

            # Programm beenden und Graphen zeichnen
            if val.lower() == 'q':
                print("Sende Shutdown-Befehl (OVER)...")
                ser.write(b"OVER\n")
                while True:
                    line = ser.readline().decode('utf-8', errors='ignore').strip()
                    if line == "SHUTDOWN_DONE":
                        print("Hardware sicher abgeschaltet.")
                        break

                # Abschluss-Plot der Hysteresekurve und der erreichten Ziele generieren
                if len(final_currents) > 0:
                    print("Erstelle und speichere den Ergebnis-Plot...")
                    plt.figure(figsize=(10, 6))

                    # Suchpfad (grau gepunktet)
                    if len(path_currents) > 0:
                        plt.plot(path_currents, path_strains, label='Suchpfad (Regler-Zwischenschritte)', marker='.',
                                 linestyle=':', color='gray', alpha=0.6, markersize=5, zorder=1)

                    # Soll-Ziele (blau)
                    plt.plot(final_currents, final_targets, label='Ziel-Dehnung (Soll)', marker='o', linestyle='None',
                             color='blue', alpha=0.5, markersize=8, zorder=2)

                    # Ist-Ziele (rote Sterne)
                    plt.plot(final_currents, final_strains, label='Erreichte Ist-Dehnung', marker='*', linestyle='-',
                             color='red', markersize=15, markeredgecolor='black', zorder=3)

                    plt.xlabel('Strom [A]')
                    plt.ylabel('Dehnung [%]')
                    plt.title('Hystereseverlauf: Suchpfad vs. Finale Ziele (FF+P Regler)')
                    plt.legend()
                    plt.grid(True)
                    plt.tight_layout()
                    plt.savefig('testergebnis_hysterese.png')
                    plt.show()
                break

            # Konvertiere Eingabe zu Float und starte den Suchalgorithmus
            target = float(val)
            print(f"\nStarte automatische Zielsuche fuer Dehnung: {target:.3f}% ...")

            is_initially_going_up = target > controller.last_real_strain
            max_auto_steps = 15
            step_count = 0

            # Automatischer Regelkreis (iterative Zielsuche)
            while step_count < max_auto_steps:
                step_count += 1
                required_I = controller.get_required_current(target)

                # Stellgröße (Strom) an Arduino senden
                ser.reset_input_buffer()
                command = f"C:{required_I:.4f}\n"
                ser.write(command.encode('utf-8'))

                actual_I = required_I
                actual_strain = target

                # Auf Antwort vom Arduino warten (Sensordaten)
                while True:
                    line = ser.readline().decode('utf-8', errors='ignore').strip()
                    if line:
                        if "IstStrom=" in line and "Dehnung=" in line:
                            match_I = re.search(r"IstStrom=\s*([-+]?\d*\.?\d+)", line)
                            match_f = re.search(r"Dehnung=\s*([-+]?\d*\.?\d+)", line)
                            if match_I: actual_I = float(match_I.group(1))
                            if match_f: actual_strain = float(match_f.group(1))
                    if line.startswith("DONE"):
                        break

                print(
                    f"   [Schritt {step_count}/{max_auto_steps}] Sende: {required_I:.4f}A | Arduino meldet: Ist-Strom={actual_I:.2f}A, Ist-Dehnung={actual_strain:.3f}%")

                # Overshoot-Erkennung für eine sauberere grafische Darstellung am Ende
                is_overshoot = False
                if is_initially_going_up and actual_strain > target + 0.06:
                    is_overshoot = True
                elif not is_initially_going_up and actual_strain < target - 0.06:
                    is_overshoot = True

                # Punkt zum Plot hinzufügen, außer es handelt sich um einen ungewollten Overshoot
                if not is_overshoot:
                    path_currents.append(actual_I)
                    path_strains.append(actual_strain)
                else:
                    print("   [Plot-Filter] Overshoot-Punkt wird im visualisierten Suchpfad ausgeblendet.")

                # Messwerte im Modell commiten
                controller.commit_current(actual_I, actual_strain, target)
                error = abs(actual_strain - target)

                # Abbruchbedingung 1: Ziel wurde erfolgreich innerhalb der Toleranz erreicht
                if error <= 0.06:
                    final_targets.append(target)
                    final_currents.append(actual_I)
                    final_strains.append(actual_strain)

                    if is_overshoot:
                        path_currents.append(actual_I)
                        path_strains.append(actual_strain)

                    print(
                        f"\nERFOLG! Ziel {target:.3f}% in {step_count} Schritten erreicht. (Ist: {actual_strain:.3f}%)")
                    print(f"Modell-Gedaechtnis (Strom): {[round(i, 3) for i in controller.history_I]}")
                    print(f"Modell-Gedaechtnis (Dehnung): {[round(i, 3) for i in controller.history_f]}")
                    print("-" * 50)
                    break

                # Abbruchbedingung 2: Strom-Limits des physikalischen Systems erreicht
                if (required_I >= controller.max_curr - 1e-3 and target > actual_strain) or \
                        (required_I <= controller.min_curr + 1e-3 and target < actual_strain):

                    final_targets.append(target)
                    final_currents.append(actual_I)
                    final_strains.append(actual_strain)

                    if is_overshoot:
                        path_currents.append(actual_I)
                        path_strains.append(actual_strain)

                    print(f"\nPHYSIKALISCHES LIMIT ERREICHT! Strom ist bei {required_I:.4f}A blockiert.")
                    print(f"Abbruch der Suche. Bestes erreichtes Ergebnis: Ist-Dehnung = {actual_strain:.3f}%")
                    print(f"Modell-Gedaechtnis (Strom): {[round(i, 3) for i in controller.history_I]}")
                    print(f"Modell-Gedaechtnis (Dehnung): {[round(i, 3) for i in controller.history_f]}")
                    print("-" * 50)
                    break

            else:
                # Maximale Iterationsanzahl erreicht, ohne dass die Bedingungen erfüllt wurden
                print(f"\nMAXIMALE ITERATIONEN ({max_auto_steps}) erreicht! Breche automatische Suche ab.")
                print(f"Letztes Ergebnis: Ist-Dehnung = {actual_strain:.3f}%")
                print("-" * 50)

        except ValueError:
            print("Ungueltige Eingabe. Bitte eine Zahl eingeben.")

    ser.close()


if __name__ == "__main__":
    main()